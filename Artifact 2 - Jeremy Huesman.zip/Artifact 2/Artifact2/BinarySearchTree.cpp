//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : Jeremy Huesman
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description :CS-499 Capstone Artifact 2 BinarySeachTree
// Date        : 
//============================================================================

#include <iostream>
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);


// define a structure to hold bid information
struct Bid {
	string bidId; // unique identifier
	string title;
	string fund;
	double amount;
	Bid() {
		amount = 0.0;
	}
};
void displayBid(Bid bid);


// FIXME (1): Internal structure for tree node
struct Node {
	// Create the internal structure
	Bid bid;
	unsigned key;
	Node* leftPtr;
	Node* rightPtr;
	Node* rootPtr;
	Node* parentPtr;

	//Default Constructor
	Node() {
		key = UINT_MAX;
		leftPtr = nullptr;
		rightPtr = nullptr;
		rootPtr = nullptr;
		parentPtr = nullptr;
	}

	// Initialize with give bid
	Node(Bid aBid) : Node() {
		bid = aBid;
	}

	Node(Bid aBid, unsigned aKey) : Node(aBid) {
		bid = aBid;
		key = aKey;
	}

};

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
	Node* root;

	void addNode(Node* node, Bid bid);
	void inOrder(Node* node);
	Node* removeNode(Node* node, string bidId);

public:
	BinarySearchTree();
	virtual ~BinarySearchTree();
	void InOrder();
	void Insert(Bid bid, string insertMethod);
	void Remove(string bidId);
	Bid Search(string bidId);
	//ADD RemoveNode
	Node* RemoveNode(Node* node, string bidId);
};

/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
	// initialize housekeeping variables
	root = nullptr;

}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
	// recurse from root deleting every node
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
	Node* cur = root;

	if (cur == nullptr) {
		return;
	}

	inOrder(root->leftPtr);
	displayBid(root->bid);
	inOrder(root->rightPtr);
}
/**
 * Insert a bid
 */
void BinarySearchTree::Insert(Bid bid, string insertMethod) {

	Node* newNode = new Node(bid);
	// FIXME (2a) Implement inserting a bid into the tree
	// Inserting a bid to the tree
	if (root == nullptr) {
		root = newNode;
		newNode->leftPtr = nullptr;
		newNode->rightPtr = nullptr;
		newNode->parentPtr = nullptr;

	}

	else {
		Node* cur = root;
				
		//Sets current node while not 0
		while (cur != nullptr) {

			if (insertMethod == "bidId") {
				//if the new node is less than the current node follow left branch
				if (newNode->bid.bidId.compare(cur->bid.bidId) < 0) {
					
					//Checks if left branch is empty will insert a new node
					if (cur->leftPtr == nullptr) {
						cur->leftPtr = newNode;
						cur = 0;
					}

					//Moves down the current node down left branch if the left node is not empty					
					else {
						cur = cur->leftPtr;
					}
				}
				//Checks to see if the new node is greater than the current node.  
				//Will move to follow right branch if it is
				else {
					if (cur->rightPtr == nullptr) {
						cur->rightPtr = newNode;
						cur = nullptr;
					}

					else {
						cur = cur->rightPtr;
					}
				}
			}

			else if (insertMethod == "title") {
				//Follows the left branch if current node is less than
				if (newNode->bid.title.compare(cur->bid.title) < 0) {
					//Inserts new node if empty
					if (cur->leftPtr == nullptr) {
						cur->leftPtr = newNode;
						cur = 0;
					}

					//If node is not empty moves down the left branch
					else {
						cur = cur->leftPtr;
					}
				}
				//If new node is greather it follows the right branch
				else {
					if (cur->rightPtr == nullptr) {
						cur->rightPtr = newNode;
						cur = nullptr;
					}

					else {
						cur = cur->rightPtr;
					}
				}
			}

			else if (insertMethod == "fund") {
				//Follows the left branch if current node is less than
				if (newNode->bid.fund.compare(cur->bid.fund) < 0) {
					//Inserts new node if empty
					if (cur->leftPtr == nullptr) {
						cur->leftPtr = newNode;
						cur = 0;
					}

					//If node is not empty moves down the left branch
					else {
						cur = cur->leftPtr;
					}
				}
				//If new node is greather it follows the right branch
				else {
					if (cur->rightPtr == nullptr) {
						cur->rightPtr = newNode;
						cur = nullptr;
					}

					else {
						cur = cur->rightPtr;
					}
				}
			}

			else if (insertMethod == "amount") {
				//Follows the left branch if current node is less than
				if (newNode->bid.amount > (cur->bid.amount)) {
					//Inserts new node if empty
					if (cur->leftPtr == nullptr) {
						cur->leftPtr = newNode;
						cur = 0;
					}

					//If node is not empty moves down the left branch
					else {
						cur = cur->leftPtr;
					}
				}
				//If new node is greather it follows the right branch
				else {
					if (cur->rightPtr == nullptr) {
						cur->rightPtr = newNode;
						cur = nullptr;
					}

					else {
						cur = cur->rightPtr;
					}
				}
			}
		}

		newNode->leftPtr = nullptr;
		newNode->rightPtr = nullptr;
	}
}
/**
 * Remove a bid
 */
void BinarySearchTree::Remove(string bidId) {
	this->removeNode(root, bidId);

}

/**
 * Search for a bid
 */
Bid BinarySearchTree::Search(string bidId) {
	// FIXME (3) Implement searching the tree for a bid
	//Start Search
	Bid bid;

	Node* current = root;

	while (current != nullptr) {
		//If current node matched, return
		if (bidId.compare(current->bid.bidId) == 0) {
			bid = current->bid;
			return bid;
		}

		else if (bidId.compare(current->bid.bidId) < 0) {
			current = current->leftPtr;
		}

		else {
			current = current->rightPtr;
		}
	}
	return bid;
}

/**
 * Add a bid to some node (recursive)
 *
 * @param node Current node in tree
 * @param bid Bid to be added
 */
void BinarySearchTree::addNode(Node* node, Bid bid) {
	// FIXME (2b) Implement inserting a bid into the tree
	//If Node is larger than the bid, add to left subtree
	if (node->bid.bidId.compare(bid.bidId) > 0) {
		if (node->leftPtr == nullptr) {
			node->leftPtr = new Node(bid);
		}
		else {
			this->addNode(node->leftPtr, bid);
		}
	}
	//Add to right subtree
	else {
		if (node->bid.bidId.compare(bid.bidId) < 0) {
			if (node->rightPtr == nullptr) {
				node->rightPtr = new Node(bid);
			}
			else {
				this->addNode(node->rightPtr, bid);
			}
		}
	}
}
void BinarySearchTree::inOrder(Node* node) {

	if (node == nullptr) {
		return;
	}

	inOrder(node->leftPtr);
	displayBid(node->bid);
	inOrder(node->rightPtr);

}

Node* BinarySearchTree::removeNode(Node* node, string bidId) {
	//Create removeNode node
	Node* currentNode = node;
	//If node is null then return
	if (currentNode == nullptr) {
		return node;
	}

	//Goes down the left subtree
	if (bidId.compare(node->bid.bidId) < 0) {
		node->leftPtr = removeNode(node->leftPtr, bidId);
	}

	//Goes down the right
	else if (bidId.compare(node->bid.bidId) > 0) {
		node->rightPtr = removeNode(node->rightPtr, bidId);
	}

	//When the compared bids are equal, the node has been found and can be removed
	else {
		//No children = Leaf Node
		if (node->leftPtr == 0 && node->rightPtr == nullptr) {
			delete node;
			node = nullptr;
		}

		//One child to the left
		else if (node->leftPtr != nullptr && node->rightPtr == nullptr) {
			Node* temp = node;
			node = node->leftPtr;
			delete temp;
		}

		//One child to the right
		else if (node->leftPtr == nullptr && node->rightPtr != nullptr) {
			Node* temp = node;
			node = node->rightPtr;
			delete temp;
		}

		//Two children
		else {
			Node* temp = node->rightPtr;
			while (temp->leftPtr != nullptr) {
				temp = temp->leftPtr;
			}
			node->bid = temp->bid;
			node->rightPtr = removeNode(node->rightPtr, temp->bid.bidId);
		}

	}
	return node;
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
	cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
		<< bid.fund << endl;
	return;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void loadBids(string csvPath, BinarySearchTree* bst, string insertMethod) {
	cout << "Loading CSV file " << csvPath << endl;

	// initialize the CSV Parser using the given path
	csv::Parser file = csv::Parser(csvPath);

	// read and display header row - optional
	vector<string> header = file.getHeader();
	for (auto const& c : header) {
		cout << c << " | ";
	}
	cout << "" << endl;

	try {
		// loop to read rows of a CSV file
		for (unsigned int i = 0; i < file.rowCount(); i++) {

			// Create a data structure and add to the collection of bids
			Bid bid;
			bid.bidId = file[i][1];
			bid.title = file[i][0];
			bid.fund = file[i][8];
			bid.amount = strToDouble(file[i][4], '$');

			//cout << "Item: " << bid.title << ", Fund: " << bid.fund << ", Amount: " << bid.amount << endl;

			// push this bid to the end
			bst->Insert(bid, insertMethod);
		}
	}
	catch (csv::Error& e) {
		std::cerr << e.what() << std::endl;
	}
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
	str.erase(remove(str.begin(), str.end(), ch), str.end());
	return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

	// process command line arguments
	string csvPath, bidKey;
	switch (argc) {
	case 2:
		csvPath = argv[1];
		bidKey = "98109";
		break;
	case 3:
		csvPath = argv[1];
		bidKey = argv[2];
		break;
	default:
		csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
		bidKey = "98109";
	}

	// Define a timer variable
	clock_t ticks;

	// Define a binary search tree to hold all bids
	BinarySearchTree* bst{};

	Bid bid;

	string answer;

	int choice2 = 0;
	int choice = 0;
	while (choice != 9) {
		cout << "Menu:" << endl;
		cout << "  1. Load Bids" << endl;
		cout << "  2. Display All Bids" << endl;
		cout << "  3. Find Bid" << endl;
		cout << "  4. Remove Bid" << endl;
		//Added Option to sort bids
		cout << "  5. Sort Bids" << endl;
		cout << "  9. Exit" << endl;
		cout << "Enter choice: ";
		cin >> choice;

		switch (choice) {

		case 1:
			bst = new BinarySearchTree();

			// Initialize a timer variable before loading bids
			ticks = clock();

			// Complete the method call to load the bids
			loadBids(csvPath, bst, "bidId");

			//cout << bst->Size() << " bids read" << endl;

			// Calculate elapsed time and display result
			ticks = clock() - ticks; // current clock ticks minus starting clock ticks
			cout << "time: " << ticks << " clock ticks" << endl;
			cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
			break;

		case 2:
			bst->InOrder();
			break;

		case 3:
			ticks = clock();

			cout << "Would you like to enter a bid ID to search for? (y/n)" << endl;
			cin >> answer;

			if (answer.compare("y") == 0 || answer.compare("Y") == 0) {
				cout << "Enter bid ID to remove." << endl;
				cin >> bidKey;
				bid = bst->Search(bidKey);
			}

			else {
				cout << "Searching for the default bid ID." << endl;
				bid = bst->Search(bidKey);
			}

			ticks = clock() - ticks; // current clock ticks minus starting clock ticks

			if (!bid.bidId.empty()) {
				displayBid(bid);
			}
			else {
				cout << "Bid Id " << bidKey << " not found." << endl;
			}

			cout << "time: " << ticks << " clock ticks" << endl;
			cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

			break;

		//Added prompts to remove bid instead of just removing with no prompt
		case 4:
			cout << "Would you like to enter a bid ID to remove?(y or n)" << endl;
			cin >> answer;

			if (answer.compare("y") == 0 || answer.compare("Y") == 0) {
				cout << "Please enter bid ID you wish to remove." << endl;
				cin >> bidKey;
				bst->Remove(bidKey);
				break;
			}

			else {
				cout << "Removing bid ID." << endl;
				bst->Remove(bidKey);
				break;
			}

			break;


		case 5:
			cout << "Please select the option you wish to sort by:" << endl;
			cout << "	1. Bid ID" << endl;
			cout << "	2. Name" << endl;
			cout << "	3. Fund" << endl;
			cout << "	4. Amount" << endl;


			cin >> choice2;

			switch (choice2) {

			case 1:
				bst = new BinarySearchTree();
				loadBids(csvPath, bst, "bidId");
				bst->InOrder();

				break;

			case 2:
				bst = new BinarySearchTree();
				loadBids(csvPath, bst, "title");
				bst->InOrder();

				break;

			case 3:
				bst = new BinarySearchTree();
				loadBids(csvPath, bst, "fund");
				bst->InOrder();

				break;

			case 4:
				bst = new BinarySearchTree();
				loadBids(csvPath, bst, "amount");
				bst->InOrder();

				break;

			}

		}

	}

	cout << "Good bye." << endl;

	return 0;
}
